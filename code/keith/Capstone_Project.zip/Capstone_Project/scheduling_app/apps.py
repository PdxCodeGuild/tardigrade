from django.apps import AppConfig


class SchedulingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scheduling_app'
