from django.contrib import admin
from scheduling_app.models import Event

admin.site.register(Event)
